import java.util.*;

public class TASK_1B {
    public static void main(String[] args) {
        System.out.println("Hello world");
    }
}
